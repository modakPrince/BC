dict_gn = {
    'Kanjur': {'Vikroli': 5, 'Bhandup': 8},
    'Vikroli': {'Kanjur': 5, 'Bhandup': 3, 'Nahur': 4},
    'Bhandup': {'Kanjur': 8, 'Vikroli': 3, 'Nahur': 2, 'Mulund': 6},
    'Nahur': {'Vikroli': 4, 'Bhandup': 2, 'Mulund': 3},
    'Mulund': {'Bhandup': 6, 'Nahur': 3, 'Diva': 7},
    'Diva': {'Mulund': 7}
}
dict_hn = {
    'Kanjur': 15,    # Kanjur is 15km from Diva (straight line)
    'Vikroli': 12,   # Vikroli is 12km from Diva  
    'Bhandup': 9,    # Bhandup is 9km from Diva
    'Nahur': 6,      # Nahur is 6km from Diva
    'Mulund': 3,     # Mulund is very close to Diva
    'Diva': 0        # Diva is the goal! (distance = 0)
}