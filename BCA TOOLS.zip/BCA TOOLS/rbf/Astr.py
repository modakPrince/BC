from queue import PriorityQueue
from data import dict_gn, dict_hn
start_place = "Kanjur"
goal_place = "Diva"
def calculate_path_cost(path_string):
    places_list = path_string.split(",")
    distance_traveled = 0
    for i in range(len(places_list) - 1):
        from_place = places_list[i]
        to_place = places_list[i + 1]
        distance_traveled = distance_traveled + dict_gn[from_place][to_place]
    current_place = places_list[-1]
    distance_left = dict_hn[current_place]
    total_cost = distance_traveled + distance_left
    return total_cost
def find_best_path():
    paths_to_check = PriorityQueue()
    paths_to_check.put((calculate_path_cost(start_place), start_place))
    while not paths_to_check.empty():
        current_cost, current_path = paths_to_check.get()
        path_places = current_path.split(",")
        last_place = path_places[-1]
        if last_place == goal_place:
            return current_path + " (total cost: " + str(current_cost) + ")"
        for next_place in dict_gn.get(last_place, {}):
            new_path = current_path + "," + next_place
            new_cost = calculate_path_cost(new_path)
            paths_to_check.put((new_cost, new_path))
    return "Sorry, no path found!"
print("Starting from:", start_place)
print("Going to:", goal_place)
print("Best route found:", find_best_path())