# Mini RBFS - Super Easy!
g = {'A':[('B',2),('C',5)], 'B':[('A',2),('D',3)], 'C':[('A',5),('D',1)], 'D':[('B',3),('C',1)]}
h = {'A':4, 'B':2, 'C':1, 'D':0}

def rbfs(n, goal, limit=99, path=None, cost=0):
    if not path: path = [n]
    if n == goal: return path, cost
    
    kids = [(k, cost+c, cost+c+h[k]) for k,c in g[n] if k not in path]
    if not kids: return None, 99
    
    while True:
        kids.sort(key=lambda x: x[2])
        best = kids[0]
        if best[2] > limit: return None, best[2]
        
        alt = kids[1][2] if len(kids) > 1 else 99
        result, new_cost = rbfs(best[0], goal, min(limit, alt), path+[best[0]], best[1])
        kids[0] = (best[0], best[1], new_cost)
        if result: return result, new_cost

path, cost = rbfs('A', 'D')
print(f"Path: {path}, Cost: {cost}")