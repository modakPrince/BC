from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split
from sklearn.naive_bayes import GaussianNB

# 1. Load dataset (example: Iris dataset)
data = load_iris()
X, y = data.data, data.target

# 2. Split into train and test sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=42)

# 3. Create and train Naive Bayes model
model = GaussianNB()
model.fit(X_train, y_train)

# 4. Predict class probabilities for test data
probs = model.predict_proba(X_test)

# 5. Show example predictions and probabilities
for i in range(5):  # just show first 5 examples
    print(f"Sample {i+1}: True Label={y_test[i]}, Predicted={model.predict([X_test[i]])[0]}")
    print("Class Probabilities:", probs[i])
    print()