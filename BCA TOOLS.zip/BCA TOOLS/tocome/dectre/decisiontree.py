# Super Easy Decision Tree - Should I Go Out?
from sklearn.tree import DecisionTreeClassifier, plot_tree
import matplotlib.pyplot as plt
# Tiny Dataset - Only 4 examples! Easy to remember!
# Weather: 0=Bad, 1=Good
# Mood: 0=Sad, 1=Happy  
# Go Out: 0=No, 1=Yes
# Training data
X = [[0,0], [0,1], [1,0], [1,1]]  # [weather, mood]
y = [0, 0, 0, 1]                  # [no, no, no, yes]
print(" Simple Decision Tree Learning!")
print("Training data:")
conditions = ["Bad weather + Sad mood", "Bad weather + Happy mood", "Good weather + Sad mood", "Good weather + Happy mood"]
answers = ["Stay home", "Stay home", "Stay home", "Go out!"]
for i in range(4):
    print(f"  {conditions[i]} -> {answers[i]}")
# Train the tree
tree = DecisionTreeClassifier()
tree.fit(X, y)
# Test new examples
print("\n🔮 Testing new situations:")
tests = [
    ([1, 1], "Good weather + Happy mood"),
    ([0, 1], "Bad weather + Happy mood"), 
    ([1, 0], "Good weather + Sad mood"),
    ([0, 0], "Bad weather + Sad mood")
]
for test_data, description in tests:
    prediction = tree.predict([test_data])[0]
    result = "Go out!" if prediction == 1 else "Stay home"
    print(f"  {description} -> {result}")

# Show accuracy
predictions = tree.predict(X)
correct = sum(p == a for p, a in zip(predictions, y))
print(f"\n Accuracy: {correct}/{len(y)} = {correct/len(y)*100:.0f}%")

#  Show the Decision Tree on Screen! 
print("\n Displaying Decision Tree...")
plt.figure(figsize=(10, 6))
plot_tree(tree, 
          feature_names=['Weather', 'Mood'], 
          class_names=['Stay Home', 'Go Out'],
          filled=True, 
          rounded=True,
          fontsize=12)
plt.title("Simple Decision Tree - Should I Go Out?", fontsize=16)
plt.show()
