#  Super Easy SVM - Cancer Detection Made Simple!
from sklearn.datasets import load_breast_cancer
from sklearn.svm import SVC
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
import matplotlib.pyplot as plt

# Step 1: Get simple data (just 2 measurements for easy understanding)
data = load_breast_cancer()
X = data.data[:, :2]  # Only first 2 features (size & texture)
y = data.target       # 0=cancer, 1=healthy

print(" SVM Cancer Detector")
print("Using only 2 measurements: Size and Texture")
print(f"Total samples: {len(X)}")

# Step 2: Split data (80% training, 20% testing)
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Step 3: Make numbers similar size (important for SVM)
scaler = StandardScaler()
X_train = scaler.fit_transform(X_train)
X_test = scaler.transform(X_test)

# Step 4: Create and train SVM (Support Vector Machine)
svm = SVC(kernel='rbf', C=1)  # RBF = curved decision line
svm.fit(X_train, y_train)

# Step 5: Test the model
predictions = svm.predict(X_test)
accuracy = (predictions == y_test).mean()

print(f"\n Results:")
print(f"Accuracy: {accuracy:.1%}")

# Count correct predictions
correct = sum(predictions == y_test)
total = len(y_test)
print(f"Got {correct} out of {total} predictions right!")

# Step 6: Show simple confusion matrix
cancer_correct = sum((y_test == 0) & (predictions == 0))
healthy_correct = sum((y_test == 1) & (predictions == 1))
cancer_wrong = sum((y_test == 0) & (predictions == 1))
healthy_wrong = sum((y_test == 1) & (predictions == 0))

print(f"\n Detailed Results:")
print(f"Cancer detected correctly: {cancer_correct}")
print(f"Healthy detected correctly: {healthy_correct}")
print(f"Missed cancer cases: {cancer_wrong}")
print(f"False alarms: {healthy_wrong}")

# Step 7: Simple visualization
plt.figure(figsize=(10, 4))

# Plot 1: Training data
plt.subplot(1, 2, 1)
plt.scatter(X_train[y_train==0, 0], X_train[y_train==0, 1], c='red', label='Cancer', alpha=0.6)
plt.scatter(X_train[y_train==1, 0], X_train[y_train==1, 1], c='blue', label='Healthy', alpha=0.6) 
plt.title("Training Data")
plt.xlabel("Size (normalized)")
plt.ylabel("Texture (normalized)")
plt.legend()

# Plot 2: Test results
plt.subplot(1, 2, 2)
correct_mask = predictions == y_test
plt.scatter(X_test[correct_mask, 0], X_test[correct_mask, 1], c='green', label='Correct', alpha=0.8, s=50)
plt.scatter(X_test[~correct_mask, 0], X_test[~correct_mask, 1], c='black', label='Wrong', alpha=0.8, s=50, marker='x')
plt.title("Test Results")
plt.xlabel("Size (normalized)")  
plt.ylabel("Texture (normalized)")
plt.legend()

plt.tight_layout()
plt.show()

print("\n SVM successfully learned to detect cancer patterns!")
