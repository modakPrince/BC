import time
from bfs import find_path
from idfs import dfs

# Test both algorithms
start, goal = 'A', 'J'

# Time BFS
print("Testing BFS...")
start_time = time.time()
bfs_path = find_path(start, goal)
bfs_time = time.time() - start_time

# Time DFS  
print("Testing DFS...")
start_time = time.time()
dfs_path = dfs(start, goal)
dfs_time = time.time() - start_time

# Show results
print("\n--- RESULTS ---")
print(f"BFS Path: {bfs_path}")
print(f"DFS Path: {dfs_path}")
print(f"BFS Time: {bfs_time:.6f} seconds")
print(f"DFS Time: {dfs_time:.6f} seconds")

# Compare speed
if bfs_time < dfs_time:
    print("🏆 BFS wins!")
elif dfs_time < bfs_time:
    print("🏆 DFS wins!")
else:
    print("🤝 It's a tie!")