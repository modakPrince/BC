# Simple map showing connections
graph = {'A':['B','C'], 'B':['D','E'], 'C':['F','G'], 'D':['H','I'], 'E':['J'], 'F':['K']}

def dfs(start, goal):
    paths = [[start]]    # List of paths to try
    visited = set()      # Remember visited places
    
    while paths:
        path = paths.pop()           # Take last path
        current = path[-1]           # Current location
        
        if current == goal:          # Found goal?
            return path
        
        if current not in visited:   # New place?
            visited.add(current)     # Mark as visited
            # Add new paths for neighbors
            for neighbor in reversed(graph.get(current, [])):
                paths.append(path + [neighbor])

# Run and print result
print("DFS path:", dfs('A', 'J'))