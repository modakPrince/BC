from collections import deque

# Map of connections
map = {'A':['B','C'], 'B':['D','E'], 'C':['F','G'], 'D':['H','I'], 'E':['J'], 'F':['K']}

def find_path(start, goal):
    queue = deque([[start]])    # Paths to check
    seen = set()                # Places visited
    
    while queue:
        path = queue.popleft()  # Take first path
        here = path[-1]         # Where am I?
        
        if here == goal:        # Found it!
            return path
        
        if here not in seen:    # New place?
            seen.add(here)      # Remember it
            # Add new paths
            for next in map.get(here, []):
                queue.append(path + [next])

print("BFS result:", find_path('A', 'J'))