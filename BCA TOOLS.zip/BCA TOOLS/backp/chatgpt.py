import numpy as np
# Activation function (sigmoid) and derivative
def sigmoid(x):
    return 1 / (1 + np.exp(-x))
def sigmoid_deriv(x):
    return x * (1 - x)
# Simple Feed Forward Neural Network (1 hidden layer)
class SimpleNN:
    def __init__(self, input_size, hidden_size, output_size, lr=0.1):
        self.lr = lr
        # Random weights
        self.W1 = np.random.rand(input_size, hidden_size)
        self.W2 = np.random.rand(hidden_size, output_size)
        
    def forward(self, X):
        self.z1 = sigmoid(np.dot(X, self.W1))
        self.z2 = sigmoid(np.dot(self.z1, self.W2))
        return self.z2
    
    def backward(self, X, y, output):
        error = y - output
        d_output = error * sigmoid_deriv(output)
        d_hidden = d_output.dot(self.W2.T) * sigmoid_deriv(self.z1)
        
        # Update weights
        self.W2 += self.z1.T.dot(d_output) * self.lr
        self.W1 += X.T.dot(d_hidden) * self.lr

    def train(self, X, y, epochs=1000):
        for _ in range(epochs):
            output = self.forward(X)
            self.backward(X, y, output)
# Example: Train on XOR dataset
X = np.array([[0,0],[0,1],[1,0],[1,1]])
y = np.array([[0],[1],[1],[0]])
nn = SimpleNN(input_size=2, hidden_size=2, output_size=1, lr=0.5)
nn.train(X, y, epochs=5000)
# Test
print("Predictions after training:")
print(nn.forward(X))

