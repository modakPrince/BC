import numpy as np
# Step 1: Simple math to make numbers 0 to 1
def magic(x):
    return 1 / (1 + np.exp(-x))
# Step 2: How much to fix mistakes
def fix_amount(x):
    return x * (1 - x)
# Step 3: Create a mini brain
w1 = np.random.uniform(-1, 1, (2, 2))  # First connections
w2 = np.random.uniform(-1, 1, (2, 1))  # Second connections
# Step 4: Teaching data - XOR (like a special switch)
X = [[0,0], [0,1], [1,0], [1,1]]  # Input switches
Y = [0, 1, 1, 0]                  # Expected light (0=OFF, 1=ON)
print("🧠 Mini Brain Learning XOR:")
print("0,0 → 0  |  0,1 → 1  |  1,0 → 1  |  1,1 → 0")
print("Learning...")
# Step 5: Train the brain (super simple loop)
for i in range(3000):
    for j in range(4):
        # Forward: Think about the answer
        inputs = np.array([X[j]])
        hidden = magic(np.dot(inputs, w1))
        output = magic(np.dot(hidden, w2))
        
        # Backward: Learn from mistakes
        target = Y[j]
        error = target - output
        
        # Fix the connections
        d_output = error * fix_amount(output)
        error_hidden = d_output.dot(w2.T)
        d_hidden = error_hidden * fix_amount(hidden)
        
        w2 += hidden.T.dot(d_output) * 0.5
        w1 += inputs.T.dot(d_hidden) * 0.5
    
    # Show progress
    if i % 500 == 0:
        print(f"Training round {i}...")

# Step 6: Test the smart brain
print("\n Testing Results:")
for i in range(4):
    inputs = np.array([X[i]])
    hidden = magic(np.dot(inputs, w1))
    result = magic(np.dot(hidden, w2))
    
    answer = "ON" if result[0] > 0.5 else "OFF"
    expected = "ON" if Y[i] == 1 else "OFF"
    check = "" if answer == expected else ""
    
    print(f"Input {X[i]} -> {answer} (expected {expected}) {check}")

print("\n Brain learned the XOR pattern!")
